// ------------------------------------------------------------------
//   visual-c-stdbool.h
//   Copyright (C) 2020 Divon Lan <divon@genozip.com>
//   Please see terms and conditions in the files LICENSE.non-commercial.txt and LICENSE.commercial.txt

#ifndef VISUAL_C_STDBOOL_INCLUDED
#define VISUAL_C_STDBOOL_INCLUDED

#ifndef bool
#define bool int
#endif

#ifndef true
#define true  1
#define false 0
#endif

#endif