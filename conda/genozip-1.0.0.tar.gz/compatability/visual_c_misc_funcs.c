// ------------------------------------------------------------------
//   visual_c_misc_funcs.c
//   Copyright (C) 2020 Divon Lan <genozip@blackpawventures.com>
//   Please see terms and conditions in the files LICENSE.non-commercial.txt and LICENSE.commercial.txt

#ifdef _MSC_VER

#include <windows.h>
#include "genozip.h"

void usleep(uint64_t usec) 
{ 
    Sleep (usec / 1000);
}

double log2 (double n)  
{  
    static double loge2 = 0; // really a constant
    if (!loge2) loge2 = log(2);

    return log(n) / loge2;  
}  

#endif